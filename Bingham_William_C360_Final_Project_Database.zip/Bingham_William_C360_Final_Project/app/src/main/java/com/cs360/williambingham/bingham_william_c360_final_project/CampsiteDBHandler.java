package com.cs360.williambingham.bingham_william_c360_final_project;

import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObservable;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

public class CampsiteDBHandler extends SQLiteOpenHelper{

    // database name and version
    private static final int DB_VER = 1;
    private static final String DB_NAME = "campsiteDB40.db";

    //table
    public static final String TABLE_CAMPSITES = "campsites";

    // columns
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_FEATURE = "feature";
    public static final String COLUMN_CITY = "city";
    public static final String COLUMN_RATE = "rate";

    // constructor
    public CampsiteDBHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version)
    {
        super(context, DB_NAME, factory, DB_VER);
    }

    // This method creates the Campsites table when the DB is initialized
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CAMPSITE_TABLE = "CREATE TABLE " +
                TABLE_CAMPSITES + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT," +
                COLUMN_FEATURE + " TEXT," +
                COLUMN_CITY + " TEXT," +
                COLUMN_RATE + " INTEGER " + ")";
        db.execSQL(CREATE_CAMPSITE_TABLE);

        addCampsite(db, new Campsite(10, "Camp Crystal Lake", "Fear", "New Jersey"));
        addCampsite(db, new Campsite(5, "Marcus Quality Campers", "Swimming", "Orlando"));
        addCampsite(db, new Campsite(8, "Breunna's Bug Net Camp", "Bug Catching", "San Diego"));
        addCampsite(db, new Campsite(6, "Baka Ninja Lake", "Training", "Kyoto"));
        addCampsite(db, new Campsite(3, "Summer Survive Camp", "Surviving", "Columbus"));
        addCampsite(db, new Campsite(7, "Ancient Spirit Pit", "Nature", "Unknown"));
        addCampsite(db, new Campsite(9, "Killer Campsite", "Running", "Charleston"));
        addCampsite(db, new Campsite(2, "Safe Zone Campsite", "Relaxing", "Denver"));
        addCampsite(db, new Campsite(1, "Don't Fall Asleep Lake", "Anxiety", "Dallas"));

    }

    // This method closes an open DB if a new one is created.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CAMPSITES);
        onCreate(db);
    }

    // This method is used to add a Campsite record to the database
    public void addCampsite(SQLiteDatabase db, Campsite campsite) {

        String campsiteName = campsite.getName();
        String query = "SELECT * FROM " +
                TABLE_CAMPSITES + " WHERE " + COLUMN_NAME +
                " = \"" + campsiteName + "\"";

        //db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);
        cursor.moveToFirst();

        String tempCampsiteName = "";
        try {
            tempCampsiteName = cursor.getString(1);
        }
        catch (Exception e) {

        }
        if (tempCampsiteName != null && !tempCampsiteName.equals("")) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_NAME, campsite.getName());
            values.put(COLUMN_FEATURE, campsite.getFeature());
            values.put(COLUMN_CITY, campsite.getCity());
            values.put(COLUMN_RATE, campsite.getRate());

            deleteCampsite(tempCampsiteName);

            db.insert(TABLE_CAMPSITES, null, values);
        }

        else {
            ContentValues values = new ContentValues();
            values.put(COLUMN_NAME, campsite.getName());
            values.put(COLUMN_FEATURE, campsite.getFeature());
            values.put(COLUMN_CITY, campsite.getCity());
            values.put(COLUMN_RATE, campsite.getRate());

            db.insert(TABLE_CAMPSITES, null, values);
        }

    }

    public void addCampsite(Campsite campsite) {
        SQLiteDatabase db = this.getWritableDatabase();

        String campsiteName = campsite.getName();
        String query = "SELECT * FROM " +
                TABLE_CAMPSITES + " WHERE " + COLUMN_NAME +
                " = \"" + campsiteName + "\"";

       // db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);
        cursor.moveToFirst();

        String tempCampsiteName = "";
        try {
            tempCampsiteName = cursor.getString(1);
        }
        catch (Exception e) {

        }
        if (tempCampsiteName != null && !tempCampsiteName.equals("")) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_NAME, campsite.getName());
            values.put(COLUMN_FEATURE, campsite.getFeature());
            values.put(COLUMN_CITY, campsite.getCity());
            values.put(COLUMN_RATE, campsite.getRate());

            deleteCampsite(tempCampsiteName);

            db.insert(TABLE_CAMPSITES, null, values);
        }

        else {
            ContentValues values = new ContentValues();
            values.put(COLUMN_NAME, campsite.getName());
            values.put(COLUMN_FEATURE, campsite.getFeature());
            values.put(COLUMN_CITY, campsite.getCity());
            values.put(COLUMN_RATE, campsite.getRate());

            db.insert(TABLE_CAMPSITES, null, values);
        }

        db.close();
    }

    // implements the search/find functionality
    public Campsite searchCampsite(String campsiteName, String campsiteFeature, String campsiteCity) {
        String query = "";
        if (!campsiteName.equals("") && (campsiteFeature.equals("") || campsiteFeature == null && (campsiteCity.equals("") || campsiteCity == null))) {
            query = "SELECT * FROM " +
                    TABLE_CAMPSITES + " WHERE " + COLUMN_NAME +
                    " = \"" + campsiteName + "\"";
        }

        else if((campsiteName.equals("") || campsiteName == null) && !campsiteFeature.equals("") && (campsiteCity.equals("") || campsiteCity == null)) {
            query = "SELECT * FROM " +
                    TABLE_CAMPSITES + " WHERE " + COLUMN_FEATURE +
                    " = \"" + campsiteFeature + "\"";
        }


        else if((campsiteName.equals("") || campsiteName == null) && (campsiteFeature.equals("") || campsiteFeature == null) && !campsiteCity.equals("")) {
            query = "SELECT * FROM " +
                    TABLE_CAMPSITES + " WHERE " + COLUMN_CITY +
                    " = \"" + campsiteCity + "\"";
        }

        else {
            query = "SELECT * FROM " +
                    TABLE_CAMPSITES + " WHERE " + COLUMN_NAME +
                    " = \"" + campsiteName + "\"";
        }


        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(query, null);
        Campsite campsite = new Campsite();

        if (cursor.moveToFirst()) {
            //cursor.moveToFirst();
            //String test = cursor.getString(0);
            //int value = Integer.parseInt(test);
            campsite.setID(Integer.parseInt(cursor.getString(0)));
            campsite.setName(cursor.getString(1));
            campsite.setFeature(cursor.getString(2));
            campsite.setCity(cursor.getString(3));
            campsite.setRate(Integer.parseInt(cursor.getString(4)));
            cursor.close();


        } else {
            campsite = null;
        }

        db.close();
        return campsite;
    }

    public boolean updateCampsite (int id, int rate) {
        //boolean result = false;

        //tring query = " UPDATE " + TABLE_CAMPSITES +
                //" SET " + COLUMN_RATE + " = " + Integer.toString(rate) + " WHERE " + COLUMN_ID + " = " +  Integer.toString(id) + ";";

        SQLiteDatabase db = this.getWritableDatabase();

        //Cursor cursor = db.rawQuery(query, null);

        ContentValues values = new ContentValues();
        values.put(COLUMN_RATE, rate);
        int value = db.update(TABLE_CAMPSITES, values,"id=" + id, null);

        //Campsite campsite = new Campsite();

        //if (cursor.moveToFirst()) {
            //campsite.setID(Integer.parseInt(cursor.getString(0)));
            //db.delete(TABLE_CAMPSITES, COLUMN_ID + " = ?",
                    //new String[] { String.valueOf(campsite.getID())});
            //cursor.close();
            //result = true;
        //}
        //cursor.close();
        db.close();
        return true;
    }

    // implements the delete campsite functionality
    public boolean deleteCampsite (String campsiteName) {

        boolean result = false;

        String query = "SELECT * FROM " + TABLE_CAMPSITES +
                " WHERE " + COLUMN_NAME + " = \"" + campsiteName + "\"";

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        Campsite campsite = new Campsite();

        if (cursor.moveToFirst()) {
            campsite.setID(Integer.parseInt(cursor.getString(0)));
            db.delete(TABLE_CAMPSITES, COLUMN_ID + " = ?",
                    new String[] { String.valueOf(campsite.getID())});
            cursor.close();
            result = true;
        }
        db.close();
        return result;
    }
}