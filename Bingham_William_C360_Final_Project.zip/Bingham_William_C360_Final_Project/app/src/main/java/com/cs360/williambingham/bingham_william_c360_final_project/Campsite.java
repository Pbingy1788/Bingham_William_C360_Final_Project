package com.cs360.williambingham.bingham_william_c360_final_project;

class Campsite {
    // instance variables
    private int var_id;
    private String var_name;
    private int var_rate;
    private String var_feature;

    // empty constructor
    public Campsite() {
    }


    // constructor with all three variables
    public Campsite(int id, int rate, String name, String feature) {
        this.var_id = id;
        this.var_rate = rate;
        this.var_name = name;
        this.var_feature = feature;
    }

    //constructor without id
    public Campsite(int rate, String name, String feature) {
        this.var_rate = rate;
        this.var_name = name;
        this.var_feature = feature;
    }

    //constructor without id
    public Campsite(int rate, String name) {
        this.var_rate = rate;
        this.var_name = name;
        this.var_feature = "";
    }

    //setter (mutators)
    public void setID(int id) { this.var_id = id; }
    public void setName(String name) { this.var_name = name; }
    public void setFeature(String feature) { this.var_feature = feature; }
    public void setRate(int rate) { this.var_rate = rate; }

    //Getter
    public int getID(){
        return var_id;
    }

    public String getName(){
        return var_name;
    }
    public String getFeature(){
        return var_feature;
    }

    public int getRate(){
        return var_rate;
    }

}

