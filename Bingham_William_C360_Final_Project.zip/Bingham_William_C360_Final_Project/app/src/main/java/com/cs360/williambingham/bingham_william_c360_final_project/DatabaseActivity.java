package com.cs360.williambingham.bingham_william_c360_final_project;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class DatabaseActivity extends AppCompatActivity {

    TextView idView;
    EditText nameBox;
    EditText featureBox;
    EditText rateBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        idView = (TextView) findViewById(R.id.campsiteID);
        nameBox = (EditText) findViewById(R.id.campsiteName);
        featureBox = (EditText) findViewById(R.id.campsiteFeature);
        rateBox = (EditText) findViewById(R.id.rateSite);
    }

    public void addCampsite(View view) {
        CampsiteDBHandler dbHandler = new CampsiteDBHandler(this, null, null, 1);
        int rate = Integer.parseInt(rateBox.getText().toString());
        Campsite campsite = new Campsite(rate, nameBox.getText().toString(), featureBox.getText().toString());
        dbHandler.addCampsite(campsite);
        nameBox.setText("");
        featureBox.setText("");
        rateBox.setText("");
    }
    public void searchCampsite(View view) {
        CampsiteDBHandler dbHandler = new CampsiteDBHandler(this, null, null, 1);
        Campsite campsite = dbHandler.searchCampsite(nameBox.getText().toString(), featureBox.getText().toString());
        if (campsite != null) {
            idView.setText(String.valueOf(campsite.getID()));
            nameBox.setText(String.valueOf(campsite.getName()));
            featureBox.setText(String.valueOf(campsite.getFeature()));
            rateBox.setText(String.valueOf(campsite.getRate()));
        } else {
            idView.setText("Campsite not found.");
        }
    }
    public void deleteCampsite(View view) {
        CampsiteDBHandler dbHandler = new CampsiteDBHandler(this, null, null, 1);
        boolean result = dbHandler.deleteCampsite(nameBox.getText().toString());
        if (result)
        {
            idView.setText("Campsite Deleted");
            nameBox.setText("");
            featureBox.setText("");
            rateBox.setText("");
        }
        else
            idView.setText("Campsite not found.");
    }


}
