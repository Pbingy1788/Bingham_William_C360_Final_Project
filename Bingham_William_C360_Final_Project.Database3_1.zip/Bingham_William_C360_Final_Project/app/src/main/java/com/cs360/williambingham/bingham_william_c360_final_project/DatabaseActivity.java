package com.cs360.williambingham.bingham_william_c360_final_project;

import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


public class DatabaseActivity extends AppCompatActivity {

    TextView idView;
    EditText nameBox;
    EditText featureBox;
    EditText cityBox;
    EditText rateBox;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        idView = (TextView) findViewById(R.id.campsiteID);
        nameBox = (EditText) findViewById(R.id.campsiteName);
        featureBox = (EditText) findViewById(R.id.campsiteFeature);
        cityBox = (EditText) findViewById(R.id.campsiteCity);
        rateBox = (EditText) findViewById(R.id.rateSite);
        imageView = (ImageView) findViewById(R.id.imageView);
        imageView.setImageResource(R.drawable.camp_default);
    }

    public void addCampsite(View view) {
        CampsiteDBHandler dbHandler = new CampsiteDBHandler(this, null, null, 1);
        int rate = Integer.parseInt(rateBox.getText().toString());
        Campsite campsite = new Campsite(rate, nameBox.getText().toString(), featureBox.getText().toString(), cityBox.getText().toString());
        dbHandler.addCampsite(campsite);
        nameBox.setText("");
        featureBox.setText("");
        cityBox.setText("");
        rateBox.setText("");
    }
    public void searchCampsite(View view) {
        CampsiteDBHandler dbHandler = new CampsiteDBHandler(this, null, null, 1);
        Campsite campsite = dbHandler.searchCampsite(nameBox.getText().toString(), featureBox.getText().toString(), cityBox.getText().toString());
        if (campsite != null) {
            idView.setText(String.valueOf(campsite.getID()));
            nameBox.setText(String.valueOf(campsite.getName()));
            featureBox.setText(String.valueOf(campsite.getFeature()));
            cityBox.setText(String.valueOf(campsite.getCity()));
            rateBox.setText(String.valueOf(campsite.getRate()));

            if (campsite.getName().equals("Camp Crystal Lake")) {
                imageView.setImageResource(R.drawable.crystal_lake);
            }

            else if (campsite.getName().equals("Marcus Quality Campers")) {
                imageView.setImageResource(R.drawable.marcus);
            }

            else if (campsite.getName().equals("Breunna's Bug Net Camp")) {
                imageView.setImageResource(R.drawable.breunna);
            }

            else if (campsite.getName().equals("Baka Ninja Lake")) {
                imageView.setImageResource(R.drawable.baka);
            }

            else if (campsite.getName().equals("Summer Survive Camp")) {
                imageView.setImageResource(R.drawable.summer);
            }

            else if (campsite.getName().equals("Ancient Spirit Pit")) {
                imageView.setImageResource(R.drawable.anicent);
            }

            else if (campsite.getName().equals("Killer Campsite")) {
                imageView.setImageResource(R.drawable.killer);
            }

            else if (campsite.getName().equals("Safe Zone Campsite")) {
                imageView.setImageResource(R.drawable.safe);
            }

            else if (campsite.getName().equals("Don't Fall Asleep Lake")) {
                imageView.setImageResource(R.drawable.dont);
            }

            else if (campsite.getName().equals("Run For The Hills")) {
                imageView.setImageResource(R.drawable.run);
            }

            else {
                imageView.setImageResource(R.drawable.camp_default);
            }
        } else {
            idView.setText("Campsite not found.");
        }
    }

    public void updateCampsite(View view) {
        if(!(idView.getText().equals("Campsite Deleted") || idView.getText().length()==0)) {
            CampsiteDBHandler dbHandler = new CampsiteDBHandler(this, null, null, 1);
            dbHandler.updateCampsite(Integer.parseInt(idView.getText().toString()), Integer.parseInt(rateBox.getText().toString()));
        }
    }

    public void deleteCampsite(View view) {
        CampsiteDBHandler dbHandler = new CampsiteDBHandler(this, null, null, 1);
        boolean result = dbHandler.deleteCampsite(nameBox.getText().toString());
        if (result)
        {
            idView.setText("Campsite Deleted");
            nameBox.setText("");
            featureBox.setText("");
            cityBox.setText("");
            rateBox.setText("");
        }
        else
            idView.setText("Campsite not found.");
    }


}
